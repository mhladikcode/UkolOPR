package tests;

import employee.Employee;
import employee.EmployeeManager;
import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;

import java.io.IOException;
import java.util.*;

class EmployeeManagerTest {

    @Test
    void testNoDuplicatesInUniqueEmployeeList() throws IOException {
        String inputFilePath = "src/resources/employees_week.csv";
        List<Employee> employees = EmployeeManager.readEmployeesFromFile(inputFilePath);

        // Collect unique employees
        Set<Employee> uniqueEmployeesSet = new HashSet<>(employees);
        List<Employee> uniqueEmployees = new ArrayList<>(uniqueEmployeesSet);

        // Sort unique employees by last name
        uniqueEmployees.sort(Comparator.comparing(Employee::getLastName));

        // Test: Check for duplicates in the unique employees list
        Set<Employee> testSet = new HashSet<>();
        for (Employee employee : uniqueEmployees) {
            assertTrue(testSet.add(employee), "Duplicate employee found: " + employee);
        }
    }
}
