package employee;

import java.io.*;
import java.nio.file.Files;
import java.nio.file.Paths;
import java.util.*;
import java.util.stream.Collectors;

public class EmployeeManager {
    public static List<Employee> readEmployeesFromFile(String filePath) throws IOException {
        List<String> lines = Files.readAllLines(Paths.get(filePath));
        return lines.stream().skip(1).map(line -> {
            String[] parts = line.split(",");
            return new Employee(Integer.parseInt(parts[1].trim()), parts[2].trim(), parts[3].trim(), parts[0].trim());
        }).collect(Collectors.toList());
    }

    public static void writeEmployeesToFile(List<Employee> employees, String filePath) throws IOException {
        List<String> lines = new ArrayList<>();
        lines.add("ID, First Name, Last Name, Day");
        for (Employee employee : employees) {
            lines.add(employee.toString());
        }
        Files.write(Paths.get(filePath), lines);
    }
}
