package employee;

import java.util.Objects;

public class Employee implements Comparable<Employee> {
    private int id;
    private String firstName;
    private String lastName;
    private String day;

    public Employee(int id, String firstName, String lastName, String day) {
        this.id = id;
        this.firstName = firstName;
        this.lastName = lastName;
        this.day = day;
    }

    public int getId() {
        return id;
    }

    public String getFirstName() {
        return firstName;
    }

    public String getLastName() {
        return lastName;
    }

    public String getDay() {
        return day;
    }

    @Override
    public int compareTo(Employee other) {
        return Integer.compare(this.id, other.id);
    }

    @Override
    public String toString() {
        return String.format("%d, %s, %s, %s", id, firstName, lastName, day);
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;
        Employee employee = (Employee) o;
        return id == employee.id;
    }

    @Override
    public int hashCode() {
        return Objects.hash(id);
    }
}
