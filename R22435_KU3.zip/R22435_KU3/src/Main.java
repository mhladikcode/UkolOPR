import employee.Employee;
import employee.EmployeeManager;

import java.io.IOException;
import java.util.*;
import java.util.stream.Collectors;

public class Main {
    public static void main(String[] args) throws IOException {
        String inputFilePath = "src/resources/employees_week.csv";
        String outputFilePath = "src/resources/employees_week_unique.csv";

        List<Employee> employees = EmployeeManager.readEmployeesFromFile(inputFilePath);

        // Sort employees by ID and print them by day
        employees.sort(Comparator.naturalOrder());
        Map<String, List<Employee>> employeesByDay = employees.stream().collect(Collectors.groupingBy(Employee::getDay));
        employeesByDay.forEach((day, empList) -> {
            System.out.println("Day: " + day);
            empList.forEach(System.out::println);
            System.out.println("------------------------");
        });

        // Collect unique employees
        Set<Employee> uniqueEmployeesSet = new HashSet<>(employees);
        List<Employee> uniqueEmployees = new ArrayList<>(uniqueEmployeesSet);

        // Sort unique employees by last name
        uniqueEmployees.sort(Comparator.comparing(Employee::getLastName));

        // Write unique employees to file
        EmployeeManager.writeEmployeesToFile(uniqueEmployees, outputFilePath);


    }}